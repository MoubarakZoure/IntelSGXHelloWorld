#ifndef ENCLAVE_U_H__
#define ENCLAVE_U_H__

#include <stdint.h>
#include <wchar.h>
#include <stddef.h>
#include <string.h>
#include "sgx_edger8r.h" /* for sgx_satus_t etc. */


#include <stdlib.h> /* for size_t */

#define SGX_CAST(type, item) ((type)(item))

#ifdef __cplusplus
extern "C" {
#endif

#ifndef OCALL_ENCLAVE_SAMPLE_DEFINED__
#define OCALL_ENCLAVE_SAMPLE_DEFINED__
void SGX_UBRIDGE(SGX_NOCONVENTION, ocall_Enclave_sample, (const char* str));
#endif
#ifndef OCALL_PRINT_DEFINED__
#define OCALL_PRINT_DEFINED__
void SGX_UBRIDGE(SGX_NOCONVENTION, ocall_print, (int* x));
#endif
#ifndef GETRANDOM_DEFINED__
#define GETRANDOM_DEFINED__
int SGX_UBRIDGE(SGX_NOCONVENTION, getRandom, (int* x));
#endif

sgx_status_t ecall_Enclave_sample(sgx_enclave_id_t eid, int* retval);
sgx_status_t random_gen(sgx_enclave_id_t eid, int* retval);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif
