#include "Enclave_u.h"
#include <errno.h>

typedef struct ms_ecall_Enclave_sample_t {
	int ms_retval;
} ms_ecall_Enclave_sample_t;

typedef struct ms_random_gen_t {
	int ms_retval;
} ms_random_gen_t;

typedef struct ms_ocall_Enclave_sample_t {
	const char* ms_str;
} ms_ocall_Enclave_sample_t;

typedef struct ms_ocall_print_t {
	int* ms_x;
} ms_ocall_print_t;

typedef struct ms_getRandom_t {
	int ms_retval;
	int* ms_x;
} ms_getRandom_t;

static sgx_status_t SGX_CDECL Enclave_ocall_Enclave_sample(void* pms)
{
	ms_ocall_Enclave_sample_t* ms = SGX_CAST(ms_ocall_Enclave_sample_t*, pms);
	ocall_Enclave_sample(ms->ms_str);

	return SGX_SUCCESS;
}

static sgx_status_t SGX_CDECL Enclave_ocall_print(void* pms)
{
	ms_ocall_print_t* ms = SGX_CAST(ms_ocall_print_t*, pms);
	ocall_print(ms->ms_x);

	return SGX_SUCCESS;
}

static sgx_status_t SGX_CDECL Enclave_getRandom(void* pms)
{
	ms_getRandom_t* ms = SGX_CAST(ms_getRandom_t*, pms);
	ms->ms_retval = getRandom(ms->ms_x);

	return SGX_SUCCESS;
}

static const struct {
	size_t nr_ocall;
	void * table[3];
} ocall_table_Enclave = {
	3,
	{
		(void*)Enclave_ocall_Enclave_sample,
		(void*)Enclave_ocall_print,
		(void*)Enclave_getRandom,
	}
};
sgx_status_t ecall_Enclave_sample(sgx_enclave_id_t eid, int* retval)
{
	sgx_status_t status;
	ms_ecall_Enclave_sample_t ms;
	status = sgx_ecall(eid, 0, &ocall_table_Enclave, &ms);
	if (status == SGX_SUCCESS && retval) *retval = ms.ms_retval;
	return status;
}

sgx_status_t random_gen(sgx_enclave_id_t eid, int* retval)
{
	sgx_status_t status;
	ms_random_gen_t ms;
	status = sgx_ecall(eid, 1, &ocall_table_Enclave, &ms);
	if (status == SGX_SUCCESS && retval) *retval = ms.ms_retval;
	return status;
}

