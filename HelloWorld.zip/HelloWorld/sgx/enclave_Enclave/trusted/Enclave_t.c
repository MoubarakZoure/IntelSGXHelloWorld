#include "Enclave_t.h"

#include "sgx_trts.h" /* for sgx_ocalloc, sgx_is_outside_enclave */
#include "sgx_lfence.h" /* for sgx_lfence */

#include <errno.h>
#include <mbusafecrt.h> /* for memcpy_s etc */
#include <stdlib.h> /* for malloc/free etc */

#define CHECK_REF_POINTER(ptr, siz) do {	\
	if (!(ptr) || ! sgx_is_outside_enclave((ptr), (siz)))	\
		return SGX_ERROR_INVALID_PARAMETER;\
} while (0)

#define CHECK_UNIQUE_POINTER(ptr, siz) do {	\
	if ((ptr) && ! sgx_is_outside_enclave((ptr), (siz)))	\
		return SGX_ERROR_INVALID_PARAMETER;\
} while (0)

#define CHECK_ENCLAVE_POINTER(ptr, siz) do {	\
	if ((ptr) && ! sgx_is_within_enclave((ptr), (siz)))	\
		return SGX_ERROR_INVALID_PARAMETER;\
} while (0)


typedef struct ms_ecall_Enclave_sample_t {
	int ms_retval;
} ms_ecall_Enclave_sample_t;

typedef struct ms_random_gen_t {
	int ms_retval;
} ms_random_gen_t;

typedef struct ms_ocall_Enclave_sample_t {
	const char* ms_str;
} ms_ocall_Enclave_sample_t;

typedef struct ms_ocall_print_t {
	int* ms_x;
} ms_ocall_print_t;

typedef struct ms_getRandom_t {
	int ms_retval;
	int* ms_x;
} ms_getRandom_t;

static sgx_status_t SGX_CDECL sgx_ecall_Enclave_sample(void* pms)
{
	CHECK_REF_POINTER(pms, sizeof(ms_ecall_Enclave_sample_t));
	//
	// fence after pointer checks
	//
	sgx_lfence();
	ms_ecall_Enclave_sample_t* ms = SGX_CAST(ms_ecall_Enclave_sample_t*, pms);
	sgx_status_t status = SGX_SUCCESS;



	ms->ms_retval = ecall_Enclave_sample();


	return status;
}

static sgx_status_t SGX_CDECL sgx_random_gen(void* pms)
{
	CHECK_REF_POINTER(pms, sizeof(ms_random_gen_t));
	//
	// fence after pointer checks
	//
	sgx_lfence();
	ms_random_gen_t* ms = SGX_CAST(ms_random_gen_t*, pms);
	sgx_status_t status = SGX_SUCCESS;



	ms->ms_retval = random_gen();


	return status;
}

SGX_EXTERNC const struct {
	size_t nr_ecall;
	struct {void* ecall_addr; uint8_t is_priv;} ecall_table[2];
} g_ecall_table = {
	2,
	{
		{(void*)(uintptr_t)sgx_ecall_Enclave_sample, 0},
		{(void*)(uintptr_t)sgx_random_gen, 0},
	}
};

SGX_EXTERNC const struct {
	size_t nr_ocall;
	uint8_t entry_table[3][2];
} g_dyn_entry_table = {
	3,
	{
		{0, 0, },
		{0, 0, },
		{0, 0, },
	}
};


sgx_status_t SGX_CDECL ocall_Enclave_sample(const char* str)
{
	sgx_status_t status = SGX_SUCCESS;
	size_t _len_str = str ? strlen(str) + 1 : 0;

	ms_ocall_Enclave_sample_t* ms = NULL;
	size_t ocalloc_size = sizeof(ms_ocall_Enclave_sample_t);
	void *__tmp = NULL;


	CHECK_ENCLAVE_POINTER(str, _len_str);

	ocalloc_size += (str != NULL) ? _len_str : 0;

	__tmp = sgx_ocalloc(ocalloc_size);
	if (__tmp == NULL) {
		sgx_ocfree();
		return SGX_ERROR_UNEXPECTED;
	}
	ms = (ms_ocall_Enclave_sample_t*)__tmp;
	__tmp = (void *)((size_t)__tmp + sizeof(ms_ocall_Enclave_sample_t));
	ocalloc_size -= sizeof(ms_ocall_Enclave_sample_t);

	if (str != NULL) {
		ms->ms_str = (const char*)__tmp;
		if (memcpy_s(__tmp, ocalloc_size, str, _len_str)) {
			sgx_ocfree();
			return SGX_ERROR_UNEXPECTED;
		}
		__tmp = (void *)((size_t)__tmp + _len_str);
		ocalloc_size -= _len_str;
	} else {
		ms->ms_str = NULL;
	}
	
	status = sgx_ocall(0, ms);

	if (status == SGX_SUCCESS) {
	}
	sgx_ocfree();
	return status;
}

sgx_status_t SGX_CDECL ocall_print(int* x)
{
	sgx_status_t status = SGX_SUCCESS;
	size_t _len_x = sizeof(int);

	ms_ocall_print_t* ms = NULL;
	size_t ocalloc_size = sizeof(ms_ocall_print_t);
	void *__tmp = NULL;


	CHECK_ENCLAVE_POINTER(x, _len_x);

	ocalloc_size += (x != NULL) ? _len_x : 0;

	__tmp = sgx_ocalloc(ocalloc_size);
	if (__tmp == NULL) {
		sgx_ocfree();
		return SGX_ERROR_UNEXPECTED;
	}
	ms = (ms_ocall_print_t*)__tmp;
	__tmp = (void *)((size_t)__tmp + sizeof(ms_ocall_print_t));
	ocalloc_size -= sizeof(ms_ocall_print_t);

	if (x != NULL) {
		ms->ms_x = (int*)__tmp;
		if (memcpy_s(__tmp, ocalloc_size, x, _len_x)) {
			sgx_ocfree();
			return SGX_ERROR_UNEXPECTED;
		}
		__tmp = (void *)((size_t)__tmp + _len_x);
		ocalloc_size -= _len_x;
	} else {
		ms->ms_x = NULL;
	}
	
	status = sgx_ocall(1, ms);

	if (status == SGX_SUCCESS) {
	}
	sgx_ocfree();
	return status;
}

sgx_status_t SGX_CDECL getRandom(int* retval, int* x)
{
	sgx_status_t status = SGX_SUCCESS;
	size_t _len_x = sizeof(int);

	ms_getRandom_t* ms = NULL;
	size_t ocalloc_size = sizeof(ms_getRandom_t);
	void *__tmp = NULL;

	void *__tmp_x = NULL;

	CHECK_ENCLAVE_POINTER(x, _len_x);

	ocalloc_size += (x != NULL) ? _len_x : 0;

	__tmp = sgx_ocalloc(ocalloc_size);
	if (__tmp == NULL) {
		sgx_ocfree();
		return SGX_ERROR_UNEXPECTED;
	}
	ms = (ms_getRandom_t*)__tmp;
	__tmp = (void *)((size_t)__tmp + sizeof(ms_getRandom_t));
	ocalloc_size -= sizeof(ms_getRandom_t);

	if (x != NULL) {
		ms->ms_x = (int*)__tmp;
		__tmp_x = __tmp;
		if (memcpy_s(__tmp_x, ocalloc_size, x, _len_x)) {
			sgx_ocfree();
			return SGX_ERROR_UNEXPECTED;
		}
		__tmp = (void *)((size_t)__tmp + _len_x);
		ocalloc_size -= _len_x;
	} else {
		ms->ms_x = NULL;
	}
	
	status = sgx_ocall(2, ms);

	if (status == SGX_SUCCESS) {
		if (retval) *retval = ms->ms_retval;
		if (x) {
			if (memcpy_s((void*)x, _len_x, __tmp_x, _len_x)) {
				sgx_ocfree();
				return SGX_ERROR_UNEXPECTED;
			}
		}
	}
	sgx_ocfree();
	return status;
}

