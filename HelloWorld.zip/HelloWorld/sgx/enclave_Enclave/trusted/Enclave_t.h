#ifndef ENCLAVE_T_H__
#define ENCLAVE_T_H__

#include <stdint.h>
#include <wchar.h>
#include <stddef.h>
#include "sgx_edger8r.h" /* for sgx_ocall etc. */

#include "sgx_trts.h"

#include <stdlib.h> /* for size_t */

#define SGX_CAST(type, item) ((type)(item))

#ifdef __cplusplus
extern "C" {
#endif

int ecall_Enclave_sample(void);
int random_gen(void);

sgx_status_t SGX_CDECL ocall_Enclave_sample(const char* str);
sgx_status_t SGX_CDECL ocall_print(int* x);
sgx_status_t SGX_CDECL getRandom(int* retval, int* x);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif
