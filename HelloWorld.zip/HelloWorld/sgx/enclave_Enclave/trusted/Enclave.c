#include <stdarg.h>
#include <stdio.h>      /* vsnprintf */
#include "Enclave.h"
#include "Enclave_t.h"  /* print_string */
#include "sgx_trts.h"

/* 
 * printf: 
 *   Invokes OCALL to display the enclave buffer to the terminal.
 */
void printf(const char *fmt, ...) {
	char buf[BUFSIZ] = { '\0' };
	va_list ap;
	va_start(ap, fmt);
	vsnprintf(buf, BUFSIZ, fmt, ap);
	va_end(ap);
	ocall_Enclave_sample(buf);
}

int ecall_Enclave_sample() {

	return 0;
}

int random_gen() {   // my e-call
	printf("\t\t Random_gen \n");

	uint8_t buffer;
	printf("This is a random number %d \n", buffer);
	sgx_read_rand(&buffer, 8);
	printf("This is a random number %d \n", buffer);
	int random;
	int retval;
	getRandom(&retval,&random);   // o_call

	printf("\n\n\n\\n *****     My O_CALL      ******");
	printf("%d === %d  \t",random,retval);

	// remark : data is not seal before it is returned to the untrusted code
	return 0;

}

